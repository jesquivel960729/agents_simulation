import System.IO.Unsafe
import System.Random


--Obtiene las dimensiones de la matriz
getDimentions :: [[String]] -> (Int, Int)
getDimentions t =
  let n = length t
      m = length (head t)
   in (n, m)

--Inicializar matriz discreta
initMatriz :: Int -> Int -> [[String]]
initMatriz n m =
  let b = [["" | y <- [0 .. m - 1]] | x <- [0 .. n - 1]]
   in b

--genera un valor random en un intervalo definido
getDataRan :: StdGen -> Int -> Int -> (Int, StdGen)
getDataRan r x0 y0 = randomR (x0, y0) r :: (Int, StdGen)

--Devuelve un elemento de la matriz
getElementAt :: (Int, Int) -> [[String]] -> String
getElementAt pos b =
  let element = (b !! fst pos) !! snd pos
   in element

--calcula los elementos adyacentes a la cuadricula
getElementsAdjacents :: (Int, Int) -> [[String]] -> [(Int, Int, String)]
getElementsAdjacents pos b
  | not (isRange pos (n, m)) = error "la posicion esta fuera de rango"
  | otherwise =
    [ (r + fst d, c + snd d, getElementAt (r + fst d, c + snd d) b)
      | d <- zip [0, 1, 1, 1, 0, -1, -1, -1] [-1, -1, 0, 1, 1, 1, 0, -1],
        isRange (r + fst d, c + snd d) (n, m)
    ]
  where
    (n, m) = getDimentions b
    (r, c) = pos

--inserta en la matriz un elemento
setElement :: String -> (Int, Int) -> [[String]] -> [[String]]
setElement element pos b =
  let (n, m) = getDimentions b
      b1 = [[if fst pos == x && snd pos == y then element else getElementAt (x, y) b | y <- [0 .. m -1]] | x <- [0 .. n -1]]
   in b1

--inserta en la matriz un arreglo de elemntos
setElements :: String -> [(Int, Int)] -> [[String]] -> [[String]]
setElements _ [] b = b
setElements element (t : xs) b = setElements element xs (setElement element t b)


getElementRan :: StdGen -> String -> [[String]] -> Int -> ([[String]], StdGen)
getElementRan r element b k =
  let (t, r1) = getElementsRan r k b []
   in (setElements element t b, r1)

getElementsRan :: StdGen -> Int -> [[String]] -> [(Int, Int)] -> ([(Int, Int)], StdGen)
getElementsRan r 0 _ elements = (elements, r)
getElementsRan r k b elements =
  let (t, r1) = getRanPos r b
   in if t `elem` elements then getElementsRan r1 k b elements else getElementsRan r1 (k -1) b (t : elements)

getRanPos :: StdGen -> [[String]] -> ((Int, Int), StdGen)
getRanPos r b =
  let (n, m) = getDimentions b
      (q, r1) = getDataRan r 0 (n -1)
      (w, r2) = getDataRan r1 0 (m -1)
   in if getElementAt (q, w) b == "" then ((q, w), r2) else getRanPos r2 b

getCorral :: StdGen -> [[String]] -> Int -> Int -> (Int, Int) -> [[String]]
getCorral r t k count center =
  let (n, m) = getDimentions t
      b = [[if x == 0 && y < k then "C" else getElementAt (x, y) t | y <- [0 .. m -1]] | x <- [0 .. n -1]]
   in b

isRange :: (Int, Int) -> (Int, Int) -> Bool
isRange (x, y) (n, m)
  | x < 0 || x >= n || y < 0 || y >= m = False
  | otherwise = True

--Genera los datos de la matriz de forma aleatoria
generateDataMatriz :: StdGen -> [[String]] -> ([[String]], StdGen)
generateDataMatriz r b =
  let (n, m) = getDimentions b
      k = min n m
      (t, r1) = getDataRan r 1 k
      (q, r2) = getDataRan r1 1 k
      (d, r3) = getDataRan r2 1 k      
      (o, r4) = getDataRan r3 1 k
      b1 = getCorral r b t t (0, 0)
      (b2, r6) = getElementRan r4 "B" b1 t
      (b3, r7) = getElementRan r6 "R" b2 q
      (b4, r8) = getElementRan r7 "S" b3 d
      (b5, r9) = getElementRan r8 "O" b4 o
   in (b5, r9)

showMatrix :: [[String]] -> String
showMatrix rows = concat (map perRow rows)
  where rowmaxs = rowMaxs rows
        perRow cols = printRow rowmaxs elements cols ++ "\n"
          where elements = elementLengths cols

rowMaxs :: [[String]] -> [Int]
rowMaxs [] = []
rowMaxs (x:xs) = [length (show (maximum (x)))] ++ (rowMaxs xs)

elementLengths :: [String] -> [Int]
elementLengths [] = []
elementLengths (y:ys) = [length (show y)] ++ (elementLengths ys)

printRow :: [Int] -> [Int] -> [String] -> String
printRow [] (a:as) (y:ys) = ""
printRow (z:zs) (a:as) [] = ""
printRow [] [] (y:ys)     = ""
printRow [] [] []         = ""
printRow (z:zs) (a:as) (y:ys) = addSpaces (z-a) ++ show y ++ [' '] ++ printRow zs as ys

addSpaces :: Int -> String
addSpaces n = replicate n ' '

simulation :: StdGen -> [[String]] -> Int -> Int -> ([[String]], StdGen)
simulation r b t 0 = (b, r)
simulation r b t k =
  let m = mod k t      
      (q, w) = if m == 0 then changeMedio r b else (b, r)
      (qb, wb) = simulationBabys w q (getPositionBebe b)
      wr = getPositionRobots qb
      qr = simulationRobots r qb wr
   in simulation wb qr t (k - 1)

changeMedio :: StdGen -> [[String]] -> ([[String]], StdGen)
changeMedio ran b =
  let posiblelocations = [(x, y) | x <- [0 .. (n -1)], y <- [0 .. (m -1)], getElementAt (x, y) b == ""]
   in setMedioSuciedad ran posiblelocations b
  where
    (n, m) = getDimentions b

setMedioSuciedad :: StdGen -> [(Int, Int)] -> [[String]] -> ([[String]], StdGen)
setMedioSuciedad ran [] b = (b, ran)
setMedioSuciedad ran (x : xs) b =
  let (q, ran1) = getDataRan ran 0 5
      b1 = if q == 1 then setElement "S" x b else b
   in setMedioSuciedad ran1 xs b1

simulationBabys :: StdGen -> [[String]] -> [(Int, Int)] -> ([[String]], StdGen)
simulationBabys ran b [] = (b, ran)
simulationBabys ran b (x : xs) =
  let (b1, ran1) = simulationBabysMovements ran b x
   in simulationBabys ran1 b1 xs

simulationBabysMovements :: StdGen -> [[String]] -> (Int, Int) -> ([[String]], StdGen)
simulationBabysMovements ran b pos =
  let vecinos = [(x, y) | (x, y, element) <- getElementsAdjacents pos b, element == "" || element == "O"]
      b1
        | null vecinos = (b, ran)
        | otherwise =
          let len = length vecinos
              (r, ran1) = getDataRan ran 0 (len -1)
              (x, y) = vecinos !! r
              pos2 = (x - fst pos, y - snd pos)
              (movements, ran2) = (refreshMovementsBaby b pos pos2, ran1)
           in putBabySuciedad ran2 movements (x, y)
   in b1

refreshMovementsBaby :: [[String]] -> (Int, Int) -> (Int, Int) -> [[String]]
refreshMovementsBaby b posO direction
  | element == "" = setElement "B" posD (setElement "" posO b)
  | element == "O" =
    let (n, m) = getDimentions b
        objectpos = getLastObjectDirection b posD direction
     in movementsObjects b posO objectpos direction
  | otherwise = b
  where
    (posD, element) = ((fst direction + fst posO, snd direction + snd posO), getElementAt posD b)

getLastObjectDirection :: [[String]] -> (Int, Int) -> (Int, Int) -> (Int, Int)
getLastObjectDirection b posO direction =
  let (x, y) = (fst posO + fst direction, snd posO + snd direction)
      is = if x < 0 || x >= n || y < 0 || y >= m then False else True
   in if is && getElementAt (x, y) b == "O" then getLastObjectDirection b (x, y) direction else posO
  where
    (n, m) = getDimentions b

movementsObjects :: [[String]] -> (Int, Int) -> (Int, Int) -> (Int, Int) -> [[String]]
movementsObjects b posO lastObject direction =
  let notmove
        | cantMove direction lastObject (n, m) = False
        | getElementAt pos2 b /= "" = False
        | otherwise = True
      b1 = if notmove then setElement "O" pos2 b else b
      b2 = if notmove then setElement "B" pos1 (setElement "" posO b1) else b1
   in b2
  where
    (n, m) = getDimentions b
    (pos2, pos1) = ((fst lastObject + fst direction, snd lastObject + snd direction), (fst posO + fst direction, snd posO + snd direction))

cantMove :: (Int, Int) -> (Int, Int) -> (Int, Int) -> Bool
cantMove direction (x, y) (boundx, boundy)
  | direction == (-1, 0) &&  x == 0 = True
  | direction == (-1, 1) && (x == 0 || y == (boundy - 1)) = True
  | direction == (0, 1) && y == (boundy - 1) = True
  | direction == (1, 1) && (x == (boundx - 1) || y == (boundy - 1)) = True
  | direction == (1, 0) && x == (boundx - 1) = True
  | direction == (1, -1) && (x == (boundx - 1) || y == 0) = True
  | direction == (0, -1) && y == 0 = True
  | direction == (-1, -1) && (x == 0 || y == 0) = True
  | otherwise = False

putBabySuciedad :: StdGen -> [[String]] -> (Int, Int) -> ([[String]], StdGen)
putBabySuciedad ran b pos =
  let vecinos = getElementsAdjacents pos b
      posiblelocations = if null vecinos then [] else [(x, y) | (x, y, element) <- vecinos, element == ""]
      (q, w)
        | null posiblelocations = (b, ran)
        | otherwise =
          let len = length posiblelocations
              (r, ran1) = getDataRan ran 0 (len - 1)
              (x, y) = posiblelocations !! r
              (r1, ran2) = getDataRan ran1 0 5
              putS =  if r1 == 1 then setElement "S" (x, y) b else b
           in (putS, ran2)
   in (q, w)

simulationRobots :: StdGen -> [[String]] -> [(Int, Int)] -> [[String]]
simulationRobots r b [] = b
simulationRobots r b (x : xs) =
  let b1 = simulationRobot r b x
   in simulationRobots r b1 xs

simulationRobot :: StdGen -> [[String]] -> (Int, Int) -> [[String]]
simulationRobot r b pos =
  let action = getOptimeAction b pos
   in simulationAction r b action pos

getPositionRobots :: [[String]] -> [(Int, Int)]
getPositionRobots b =
  let (n, m) = getDimentions b
      tmp = [(x, y) | x <- [0 .. (n -1)], y <- [0 .. (m -1)]]
      --robots simple
      robot = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "R"
      --robots en una casilla con suciedad
      robotS = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RS"
      --robots con bebe en la mano
      robotB = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RB"
      --robots con bebe en la mano y suciedad
      robotBS = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RBS"
      --robots en corral
      robotC = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RC"
      --robots en corral con bebe cargado
      robotCB = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RCB"
      --robots en corral y un bebe en el piso
      robotCBP = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "RCBP"
   in robot ++ robotS ++ robotB ++ robotBS ++ robotC ++ robotCB ++ robotCBP

getPositionBebe :: [[String]] -> [(Int, Int)]
getPositionBebe b =
  let (n, m) = getDimentions b
      tmp = [(x, y) | x <- [0 .. (n -1)], y <- [0 .. (m -1)]]
      bebes = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "B"
   in bebes

getPositionSuciedad:: [[String]] -> [(Int, Int)]
getPositionSuciedad b =
  let (n, m) = getDimentions b
      tmp = [(x, y) | x <- [0 .. (n -1)], y <- [0 .. (m -1)]]
      suciedad = filter f tmp
        where
          f (x, y) = getElementAt (x, y) b == "S"
   in suciedad

getOptimeAction :: [[String]] -> (Int, Int) -> String
getOptimeAction b pos =
  let actions = getRobotPossibleActions b pos
      bebes = getPositionBebe b
      suciedad = getPositionSuciedad b
      action
        | "D" `elem` actions = "D"
        | length bebes == 0 && "L" `elem` actions = "L"
        | length bebes == 0 && length suciedad > 0 = "M"
        | length suciedad == 0 = "P"
        | "M" `elem` actions = "M"
        | otherwise = "P"
   in action  

simulationAction :: StdGen -> [[String]] -> String -> (Int, Int) -> [[String]]
simulationAction r b action pos =
  let robot = getElementAt pos b
      b1
        | action == "P" = b
        | action == "D" = setBebe b pos
        | action == "L" = cleanSuciedad b pos
        | action == "M" =
          let bestMove = getOptimeMovements r b pos
              tmp = (fst bestMove - fst pos, snd bestMove - snd pos)
           in if pos == bestMove then b else refreshMovementsRobot robot b pos tmp
   in b1

setBebe :: [[String]] -> (Int, Int) -> [[String]]
setBebe b pos =
  let tmp = getElementAt pos b
   in setElement "RCBP" pos b

cleanSuciedad :: [[String]] -> (Int, Int) -> [[String]]
cleanSuciedad b pos =
  let robot = getElementAt pos b
      removeSuciedad = if robot == "RS" then "R" else "RB"
   in setElement removeSuciedad pos b

getRobotPossibleMovements :: [[String]] -> (Int, Int) -> [(Int, Int)]
getRobotPossibleMovements b pos =
  let robot = getElementAt pos b
      --Si el robot tiene un bebe cargado
      enum1 = ["", "S", "C" ]
      --Si el robot no tiene bebe
      enum2 = ["", "S", "B", "C", "CB"]

      vecinos
        | robot == "RB" || robot == "RBS" || robot == "RCB" = [(x, y) | (x, y, element) <- getElementsAdjacents pos b, element `elem` enum1]
        | otherwise = [(x, y) | (x, y, element) <- getElementsAdjacents pos b, element `elem` enum2]
   in vecinos

getRobotPossibleActions :: [[String]] -> (Int, Int) -> [String]
getRobotPossibleActions b pos =
  let robot = getElementAt pos b
      movements = getRobotPossibleMovements b pos
      actions
        | robot == "R" && length movements > 0 = ["M"]
        | robot == "RS" && length movements > 0 = ["M", "L"]
        | robot == "RS" = ["L"]
        | robot == "RB" && length movements > 0 = ["M"]
        | robot == "RBS" && length movements > 0 = ["M", "L"]
        | robot == "RBS" = ["L"]
        | robot == "RC" = ["M"]
        | robot == "RCB" && length movements > 0 = ["M", "D"]
        | robot == "RCB" = ["D"] 
        | robot == "RCBP" = ["M"]
        | otherwise = ["P"]
   in actions

getOptimeMovements :: StdGen -> [[String]] -> (Int, Int) -> (Int, Int)
getOptimeMovements r b pos =
    let robot = getElementAt pos b
        posibles
          | robot == "R" = ["", "S", "B", "C"]
          | robot == "RS" = ["","S", "B", "C"]
          | robot == "RB" = ["", "S", "C"]
          | robot == "RBS" = ["","S","C"]
          | robot == "RC" = ["","S","B","C"]
          | robot == "RCB" = ["C"]
          | robot == "RCBP" = ["", "B", "S", "C"]
        bebes = getPositionBebe b
        (q, w) = chooseRobotMethod robot bebes posibles b pos 1 r
     in getPositionOptimo w pos q

chooseRobotMethod :: String -> [(Int, Int)] -> [String] -> [[String]] -> (Int, Int) -> Int -> StdGen -> ((Int, Int), [((Int, Int), (Int, Int))])
chooseRobotMethod robot bebes posible b pos selector r
  | selector == 0 =
    let (q, w)
          | robot == "RB" || robot == "RBS" = getBestOption "C" posible b pos
          | not (null bebes) = getBestOption "B" posible b pos
          | otherwise = getBestOption "S" posible b pos
      in (q, w)
  | otherwise =
    let (option, r1) = getDataRan r 1 2
        (q, w)
          | robot == "RB" || robot == "RBS" = getBestOption "C" posible b pos
          | option == 1 && not (null bebes) = getBestOption "B" posible b pos
          | otherwise = getBestOption "S" posible b pos
      in (q, w)

getBestOption :: String -> [String] -> [[String]] -> (Int, Int) -> ((Int, Int), [((Int, Int), (Int, Int))])
getBestOption option posible b pos =
  let (tuple, d) = bfs posible [pos] b [pos] [] [(pos, 0)]
      tmp = [c | (c, v) <- d, getElementAt c b == option]
      options
        | null tmp = pos
        | otherwise = head tmp
   in (options, tuple)

getPositionOptimo :: [((Int, Int), (Int, Int))] -> (Int, Int) -> (Int, Int) -> (Int, Int)
getPositionOptimo tuple posO posD
  | posO == posD = posO
  | otherwise =
    let q = head [x | (x, y) <- tuple, y == posD]
        result
          | q == posO = posD
          | otherwise = getPositionOptimo tuple posO q
     in result

bfs :: [String] -> [(Int, Int)] -> [[String]] -> [(Int, Int)] -> [((Int, Int), (Int, Int))] -> [((Int, Int), Int)] -> ([((Int, Int), (Int, Int))], [((Int, Int), Int)])
bfs _ [] _ _ tuple d = (tuple, d)
bfs posible (u : q) b visited tuple d =
  let vecinos = getElementsAdjacents u b
      vecinos1 = [(x, y, value) | (x, y, value) <- vecinos, (x, y) `notElem` visited, getElementAt (x, y) b `elem` posible]
      d' = head [v | ((x, y), v) <- d, (x, y) == u]
      ds' = d ++ [((x, y), d' + 1) | (x, y, _) <- vecinos1]
      visited' = visited ++ [(x, y) | (x, y, _) <- vecinos1]
      q' = q ++ [(x, y) | (x, y, _) <- vecinos1]
      tuple' = tuple ++ [(u, (x, y)) | (x, y, _) <- vecinos1]
   in bfs posible q' b visited' tuple' ds'

refreshMovementsRobot :: String -> [[String]] -> (Int, Int) -> (Int, Int) -> [[String]]
refreshMovementsRobot robot b posO direction
  | posO == posD = b
  | robot == "R"  =
    let b1 = setElement "" posO b
        nextstatus
          | element == "" = "R" 
          | element == "B" = "RB" 
          | element == "S" = "RS"
     in setElement nextstatus posD b1
  | robot == "RS" =
    let b1 = setElement "S" posO b
        nextstatus
          | element == "" = "R"
          | element == "B" = "RB"
          | element == "S" = "RS"
     in setElement nextstatus posD b1
  | robot == "RB" =
    let b1 = setElement "" posO b
        nextstatus
          | element == "" = "RB"
          | element == "S" = "RBS"
          | element == "C" = "RCB"
     in setElement nextstatus posD b1
  | robot == "RBS" =
    let b1 = setElement "S" posO b
        nextstatus
          | element == "" = "RB"
          | element == "S" = "RBS"
          | element == "C" = "RCB"
     in setElement nextstatus posD b1
  | robot == "RC" =
    let b1 = setElement "C" posO b
        nextstatus
          | element == "" = "R"
          | element == "B" = "RB"
          | element == "S" = "RS"
          | element == "C" = "RC"
     in setElement nextstatus posD b1
  | robot == "RCB" =
    let b1 = setElement "C" posO b
        nextstatus 
          | element == "C"  = "RCB"
     in setElement nextstatus posD b1
  | robot == "RCBP" =
    let b1 = setElement "CB" posO b
        nextstatus
          | element == "" = "R"
          | element == "B" = "RB"
          | element == "S" = "RS"
          | element == "C" = "RC"
     in setElement nextstatus posD b1
  | otherwise = b
  where
    (posD, element) = ((fst direction + fst posO, snd direction + snd posO), getElementAt posD b)

countSuciedad :: [[String]] -> Float
countSuciedad b = 100 * ( e / (s + e))
  where
    (f, c) = getDimentions b
    e = fromIntegral (length [(x, y) | x <- [0 .. (f -1)], y <- [0 .. (c -1)], getElementAt (x, y) b == ""]) :: Float
    s = fromIntegral (length [(x, y) | x <- [0 .. (f -1)], y <- [0 .. (c -1)], getElementAt (x, y) b == "S"]) :: Float

main :: IO ()
main =
  let ran = mkStdGen 4563
      b = initMatriz 20 20
      (b1, ran1) = generateDataMatriz ran b
      p = countSuciedad b1
      (b2, ran2) = simulation ran1 b1 10 200
      p1 = countSuciedad b2
      p3 = if p1 >= 60 then "La casa esta limpia" else "La casa se encuentra sucia"
   in do
        putStr "Ambiente Inicial\n"
        putStr (showMatrix b1)
        putStr "Por ciento de suciedad en el ambiente inicial : "
        print p
        putStr "\n"
        putStr "Ambiente Final\n"
        putStr (showMatrix b2)
        putStr "Por ciento de suciedad en el ambiente final : "
        print p1
        putStr "\n"
        putStr p3

        
